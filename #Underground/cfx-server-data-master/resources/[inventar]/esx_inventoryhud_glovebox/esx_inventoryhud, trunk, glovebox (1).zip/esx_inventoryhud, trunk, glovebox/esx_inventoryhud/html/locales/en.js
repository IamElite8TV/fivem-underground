var invLocale = new Object();
invLocale.dropItem = "Drop";
invLocale.useItem = "Use";
invLocale.giveItem = "Give";
invLocale.secondInventoryNotAvailable = "Second inventory is not available";