Locales["cs"] = {
	["cash"] = "Hotovost",
	["black_money"] = "Špinavé peníze",
	["player_nearby"] = "Zvolený hráč již není u tebe!",
	["players_nearby"] = "Poblíž tebe není žádný hrác!",
	["openinv_help"] = "Otevře inventář jiného hráče",
	["openinv_id"] = "ID hráče",
	["no_permissions"] = "Na toto nemáš práva!",
	["no_player"] = "Hráč se zadaným ID nebyl nalezen!",
	["player_inventory"] = "Inventář hráče"
}
